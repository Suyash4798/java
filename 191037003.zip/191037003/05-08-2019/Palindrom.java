public class Palindrom
 {
public static void main( String args[] )
 {


int length = args.length();
 
      for (int i=0; int i = length-1; i--)
      {
         String rev = rev + args.charAt(i);
      }
 
      if (args.equals(rev))
        {
        	 System.out.println(str+" is a palindrome");
        	}
      else
         System.out.println(str+" is not a palindrome");
        
 }
}