/*Write a program in java to count the number of vowels in the input string*/
public class Vowels {
	public static void main (String[] args)
	{
int cnt=0;
	for(int r=0; r < args.length ; r++ )
		{
			if( args.charAt [r]== "a"|| args.charAt [r] =="e" || args.charAt [r] =="i" ||args.charAt [r] =="o"||args.charAt [r] == "u")
			cnt = cnt +1;
		System.out.println("cnt :" +cnt);

		}
		System.out.println("vowels :" +cnt);
}}
		