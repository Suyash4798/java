{
	public static void main(String[] args)
	public class HelloWorld
{
	System.out.println("HEllo....!!!");
	}
}