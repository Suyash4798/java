/*Java program to convert minutes into a number of years and days*/
import java.util.Scanner;

public class MintoDays
{
	
	public static void main (String []args)
	{
 		 //double min=456789;
		System.out.println("Enter the minutes");
		Scanner obj=new Scanner(System.in);
		double min=obj.nextInt();

 		 int years=(int)min/(365*60*24);
		 int days=(int)(min/(60*24))%365;

   			 System.out.println("Year  :0"+ years + " Days :"+days);

	}
}



