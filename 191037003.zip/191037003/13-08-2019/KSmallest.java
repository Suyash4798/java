/*Write a Java program to find the kth smallest and largest element in a given array. Elements in the array can be in any order.*/
import java.util.*;
class KSmallest
{
	public static void main(String[] args) 
	{
	 System.out.println("enter the size of array");
	 Scanner sc=new Scanner (System.in);

	 int n=sc.nextInt();
	 int[]arr=new int[n];
	 System.out.println("enter the elements of array");
	 for(int i=0;i<n;i++)
	 {
	 	arr[i]=sc.nextInt();

	 }
	 int a=arr[0];
	int b=arr[0];
	 for(int i=1;i<arr.length;i++)
	 {
	 	if(arr[i]<a)
	 	{
	 		a=arr[i];
	 	}
	 	if(arr[i]>b)
	 	{
	 		b=arr[i];
	 	}

	 }
	 System.out.println("the smallest number is "+a);
	 System.out.println("the greatest number is"+b);

	}
}