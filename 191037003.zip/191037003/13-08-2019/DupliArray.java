import java.util.Arrays; 

// Java program to find the duplicate values of an array of integer values

public class DupliArray
{
    public static void main(String[] args) 
    {
        
        int[] myArray={2,3,2};
        
        for (int i=0;i<myArray.length-1;i++)
         {
            for (int j=i+1;j<myArray.length;j++)

            {

                if((myArray[i] == myArray[j]) && (i !=j)) 
                {
                     System.out.println("Duplicate Numbers Are : " + myArray[j]);
                }
               
            }

         
         }

    }
}