// Java program to find the numbers greater than the average of the numbers of a given array.

public class GreaterthanAverage {

	public static void main(String args[]) 
	{
			int my_array[]={1,5,3,4,8,5,6,8,45,41,87};
			int sum=0;
		 	int average=0;
			int len=my_array.length;
				
				for (int i=0;i<len;i++)
			 		{
						sum+=my_array[i];	
			   			average= sum/len;
			 		}
							//System.out.println("sum of elements"+ sum);
							System.out.println("Average of elements : "+ average);

  						for (int i=0;i<len;i++)
  							
  							{
  								if(my_array[i]>average)
  								{
  									
  									System.out.println("Greater than average of element : "+ my_array[i]);
  								}
  							}	
									



	}
}