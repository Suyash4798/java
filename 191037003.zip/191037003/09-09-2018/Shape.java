public class Shape
{
	private String color="red";
	private boolean filled = true;
	

	Shape()
	{

	} 

	Shape(String c, boolean f)
	{
		color=c;
		filled=f;
	}

	public String getColor()
	{
		return color;
	}

	public void setColor(String c)
	{
		color=c;
	}

	public boolean isFilled()
	{
		return filled;
	}

	public void setFilled(boolean f)
	{
		filled=f;
	}

	@Override
	public String toString()
	{
		return "superclass";
	}


}