public class Rectangle extends Shape
{
	protected double width;
	protected double length;

	public Rectangle(){}

	public Rectangle(double w, double l)
	{
		width=w;
		length=l;
	}

	public Rectangle(double w, double l, String c, boolean f)
	{
		
		super(c,f);
		width=w;
		length=l;
	}

	public double getWidth()
	{
		return width;
	}

	public void setWidth(double w)
	{
		width= w;
	}

	public double getLength()
	{
		return length;
	}

	public void setLength(double l)
	{
		 length=l;
	}

	public double getArea()
	{
		return width*length;
	}

	public double getPerimeter()
	{
		return width;
	}
	
	@Override
	public String toString()
	{
		return "A Rectangle with width=3 and length=4, which is a subclass of Shape";
	}
}