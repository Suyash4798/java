class InheritanceDemo
{
	public static void main(String[] args)
	{
		//Square
		Square s = new Square(3.5);
		Square s1 = new Square(3.5, "Red", true);
		s.setSide(2);
			System.out.println("Sides of a square(2*2): " +s.getSide());
			System.out.println(s);
		s1.setWidth(2.5);
		s1.setLength(2.5);
			System.out.println("Sides of a square(2.5*2.5): "+s1.getSide());
			System.out.println(s1);

		//Rectangle 
		Rectangle r = new Rectangle(2.5,2.5);
		Rectangle r1 = new Rectangle(2.5, 4.5, "Green", false);
		r.setWidth(3);
		r.setLength(4);
			System.out.println("Rectangle Length: "+r.getLength());
			System.out.println("Rectangle Area "+r.getArea());
			System.out.println("Rectangle Perimeter " +r.getPerimeter());
		System.out.println(r);

		r1.setWidth(5);
		r1.setLength(5);
			System.out.println("Rectangle Length: "+ r1.getLength());
			System.out.println("Rectangle Area "+r1.getArea());
			System.out.println("Rectangle Perimeter "+r1.getPerimeter());
		System.out.println(r1);


		//Circle
		Circle c = new Circle();
		Circle c1 = new Circle(1.0,"Red",true);
		c.setRadius(1.0);
			System.out.println("Circle Radius: "+ c.getRadius());
			System.out.println("Circle Area "+c.getArea());
			System.out.println("Circle Perimeter "+c.getPerimeter());
		System.out.println(c);
		c1.setRadius(2.5);
			System.out.println("Circle Radius: "+ c1.getRadius());
			System.out.println("Circle Area "+c1.getArea());
			System.out.println("Circle Perimeter "+c1.getPerimeter());

	}
}