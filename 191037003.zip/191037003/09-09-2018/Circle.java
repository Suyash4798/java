public class Circle extends Shape
{
	private double radius;
	private static final double PI = 3.14;
	
	Circle()
	{

	}

	Circle(double r, String c, boolean f)
	{
		super(c,f);
		radius=r;
		
	}

	public double getRadius()
	{
		return radius;
	}

	public void setRadius(double r)
	{
		radius=r;
	}

	public double getArea()
	{
		return PI*radius*radius;
	}

	public double getPerimeter()
	{
		return radius;
	}

	@Override
	public String toString()
	{
		return "Circle is :  ";
	}
	
}