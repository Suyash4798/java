public class Square extends Rectangle
{
	
	Square()
	{

	}

	public Square(double s)
	{
		super(s,s);
	}

	Square(double s, String c, boolean f)
	{
		super(s,s,c,f);
		

	}

	Square(double l, double w)
	{
		super(l,w);
		
	}

	public double getSide()
	{
		return width;
	}

	public void setSide(double s)
	{
		width=s;
		
	}

	@Override
	public void setWidth(double s)
	{
		super.setWidth(s);
	}

	@Override
	public void setLength(double s)
	{
		super.setLength(s);
	}

	@Override
	public String toString()
	{
		return "Square IS : ";
	}
}