import java.util.Scanner;


public class MenuStack
{
	public static void main(String[] args)

	 {
	 		System.out.println("Choose the size stack");	
			
			Scanner sc=new Scanner(System.in);
			int size=sc.nextInt();

			Stack s=new Stack(size);
			do
			{
				System.out.println("Choose the operation :\n 1.Push\n 2.Pop\n 3.Display\n 4.Exit\n");
				int op=sc.nextInt();
				switch(op)
				{
				case 1:

					System.out.println("Enter the number");
					int num=sc.nextInt();
					s.push(num);
					break;
				case 2:
					int value = s.pop();
					System.out.println("poped value" + value);
					break;
				case 3:
					s.disp();
					break;
				default:

				}
			}

			while(op!=4);
	 }


} 