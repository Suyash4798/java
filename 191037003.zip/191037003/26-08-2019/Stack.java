public class Stack {
   private int maxSize;
   private int[] stackArray;
   private int top;
   
   
  public Stack(int s) 
  {
      maxSize = s;
      stackArray = new int [maxSize];
      top = -1;
   }



   public void push(int i) 

   {

     if(top == maxSize - 1)
       System.out.println("Stack is full");
      else
      {
      top=top+1;
      stackArray[top] = i;
      }
   }

   public int pop() 
   {
      if(top==-1)
       System.out.println("Stack is empty");
       top=top-1;
      return stackArray[top];
   }



   public void disp() {
      if(top==-1)
       System.out.println("Stack is empty");
      System.out.println("Stack is ");
       for(int k=0;k<top;k++)
       {

           System.out.println("Stack" + stackArray[k]);
       }
   }
   
   
  
   }