class TrackObj
{
	//class variable
	private static int counter = 0;

	//instance variable
	private int x = 0;

	TrackObj()
	{
		counter++;
		x ++;
	}

	//member method
	public int getX()
	{
		return x;
	}
	
	//class method
	public static int getCounter()
	{
		return counter;
	}

}