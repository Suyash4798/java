/*Shown below is a Floyd's triangle.
1
2 3
4 5 6
7 8 9 10
11 ... ... ... 15
.
.
79 .. .. .. .. .. .. .. .. 91
*/

import java.util.*;
class Floyd1
{
	public static void main(String[] args) {
		int n, num = 1,i, j;
       
       Scanner sc = new Scanner(System.in);
       System.out.println("Enter the number of rows:");
      
       n = sc.nextInt();
       System.out.println("Floyd's triangle");
       for ( i = 1 ; i<= n ; i++ )
       {
           for ( j = 1 ; j <= i ; j++ )
           {
                System.out.print(num+" ");

                num++;
           }
           
           System.out.println();
       }
	}
}