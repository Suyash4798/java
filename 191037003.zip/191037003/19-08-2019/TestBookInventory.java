import java.util.Scanner;

public class TestBookInventory{

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter book title, author, price and stock");
		String title = sc.next();
		String author = sc.next();
		double price = sc.nextDouble();
		int stock = sc.nextInt();

		Book b1 = new Book(title, author, price, stock);
		int choice = 1;

		do{
			System.out.println("Enter book title, author");
			String title_search = sc.next();
			String author_search = sc.next();

			//search book 
			if(b1.searchBook(title_search, author_search)){
				
				b1.displayBookInfo();
				System.out.println();
				
				System.out.println("Enter number of copy");
				int copy_search = sc.nextInt();
				
				//check number of copies
				if(b1.checkNumberOfCopy(copy_search)){

					//calculate amount
					double amount = b1.calculateAmount(copy_search);
					System.out.println("Successfully issued the book, total price is :" + amount);
					
					//update stock
					b1.updateBookStock(copy_search);
				
				}else{
					System.out.println("Insufficient stock ");
				}

			}else{
				
				System.out.println("Book is not available " );
			}

			System.out.println("Do you want to contine press 1 or exit press 0" );
			choice = sc.nextInt();

		}while(choice!=0);
	}
}