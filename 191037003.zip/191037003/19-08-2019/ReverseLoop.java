/*Given a number,write a program using while loop reverse the digits of the number For example, 
the number 12345 should be written as 54321 (Hint: Use modulus operator to extract the last digit 
and the integer division by 10 to get the n-1 digit number from the n digit number) string*/
import java.util.*;
class ReverseLoop
{
	public static void main(String[] args) {
		int num , reversed = 0;
		System.out.println("enter the number");
		Scanner sc=new Scanner (System.in);
		 num=sc.nextInt();
        while(num != 0) {
            int digit = num % 10;
            reversed = reversed * 10 + digit;
            num /= 10;
        }
        System.out.println("Reversed Number: " + reversed);
	}
}