
import java.util.*;
class MaxMin
{
	public static void main(String[] args) {
		System.out.println("enter the size of array");
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		System.out.println("enter numbers.....");
		int [] numbers=new int[n];
		for(int i=0;i<n;i++)
		{
			numbers[i]=sc.nextInt();
		}
		int smallest = numbers[0];
		int largetst = numbers[0];
		
		for(int i=1; i< numbers.length; i++)
		{
			if(numbers[i] > largetst)
				largetst = numbers[i];
			else if (numbers[i] < smallest)
				smallest = numbers[i];
			
		}
		       
			Arrays.sort(numbers);
		
		System.out.println("Sorted numbers are");
		for(int i=0;i<numbers.length;i++)
		{
			System.out.println(numbers[i]);
		}
		
		System.out.println("Largest Number is : " + largetst);
		System.out.println("Smallest Number is : " + smallest);
		
	}
}