/*Write a program to find the number of and sum of all integers greater than 100 and less than 200 that are divisible by 7*/
import java.util.*;
class SumofGreater
{
	public static void main(String[] args) {
		int result=0,count=0;
		for(int i=100;i<=200;i++){
			if(i%7==0)
				result+=i;
			count++;
			System.out.println(i);
		}
		System.out.println("the total number of integers divisible by 7 are "+count);
		System.out.println("Output of Program is : "+result);
	}
}