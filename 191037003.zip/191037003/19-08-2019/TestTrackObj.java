public class TestTrackObj
{
	public static void main(String[] args) {
		

		TrackObj obj = new TrackObj();

		System.out.println("Object created: " + TrackObj.getCounter());

		System.out.println("Object x: " + obj.getX());

		TrackObj obj1 = new TrackObj();
		System.out.println("Object created: " + TrackObj.getCounter());
		
		System.out.println("Object x: " + obj1.getX());

		TrackObj obj2 = new TrackObj();
		System.out.println("Object created: " + TrackObj.getCounter());
		
		System.out.println("Object x: " + obj2.getX());

		TrackObj obj3 = new TrackObj();

		System.out.println("Object created: " + TrackObj.getCounter());
		
		System.out.println("Object x: " + obj3.getX());

	}
}