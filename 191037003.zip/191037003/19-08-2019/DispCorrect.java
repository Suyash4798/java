
 import java.util.*;
 import java.lang.*;
 class DispCorrect
 {
 	public static void main(String[] args)
 	 {	Scanner sc=new Scanner(System.in);
 		String que="National Animal?";
 		String ans="Tiger";
 		for(int i=1;i<=3;i++)
 		{	System.out.println(que);
 			String test=sc.nextLine();
 		
 			if (test.equalsIgnoreCase(ans))
 			{
 				System.out.println("WellDone !!! Correct Answer");

 			}
 			else
 			{
 				System.out.println("Sorry Wrong Answer");
 				System.out.println("You Have"+(3-i)+"chances remaining");
 			}
 		}

 	}
 }